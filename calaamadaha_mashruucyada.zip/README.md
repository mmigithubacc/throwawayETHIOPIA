# Calaamadaha Mashaariicda — Project Map Icons

Map-marker icons for displaying public projects in the Somali Region of Ethiopia
on maps designed for low-literacy audiences.

## Format
- 19 individual SVG files (vector, infinitely scalable)
- Each is a self-contained, standalone SVG marker (~64x80 px native)
- No external dependencies — open in any browser, Adobe Illustrator,
  Inkscape, Figma, QGIS, ArcGIS, or web map (Leaflet/Mapbox/Google)
- Open `preview.html` in a browser to see all icons together

## Design principles
- **Pictographic, not symbolic** — every icon depicts the thing itself
- **Distinct silhouettes** — readable at 20 px or in black-and-white
- **Color-coded by sector** — sector legible at a glance from colour alone
- **Culturally grounded** — camel for livestock (not generic cow);
  civic building for govt (not religiously coded)

## Icon set

| # | Filename | Somali | English | Sector |
|---|---|---|---|---|
| 1 | `01_iskuul.svg` | Iskuul | School | Waxbarashada |
| 2 | `02_jaamacad.svg` | Jaamacad | University / College | Waxbarashada |
| 3 | `03_isbitaal.svg` | Isbitaal | Hospital | Caafimaadka |
| 4 | `04_xarun_caafimaad.svg` | Xarun caafimaad | Health centre | Caafimaadka |
| 5 | `05_ceel_biyo.svg` | Ceel / Biyo | Well / Water | Biyaha |
| 6 | `06_biyo_xidheen.svg` | Biyo-xidheen | Reservoir / Dam | Biyaha |
| 7 | `07_wadada.svg` | Wadada | Road | Wadooyinka |
| 8 | `08_buundo.svg` | Buundo | Bridge | Wadooyinka |
| 9 | `09_garoon.svg` | Garoon | Airport | Wadooyinka |
| 10 | `10_laydhka.svg` | Laydhka | Electricity | Tamarta |
| 11 | `11_solar.svg` | Solar / Qoraxda | Solar power | Tamarta |
| 12 | `12_anteeno.svg` | Anteeno | Telecom mast | Isgaarsiinta |
| 13 | `13_beero.svg` | Beero | Farm / Crops | Beeraha |
| 14 | `14_xoolo_geel.svg` | Xoolo / Geel | Livestock (camel) | Xoolaha |
| 15 | `15_daryeel_xoolo.svg` | Daryeel xoolo | Vet clinic (paw) | Xoolaha |
| 16 | `16_xafiis_dawladda.svg` | Xafiis dawladda | Govt office | Maamulka |
| 17 | `17_guryo.svg` | Guryo wadareed | Public housing | Maamulka |
| 18 | `18_qorshe_magaaleed.svg` | Qorshe magaaleed | Master plan | Qorshe-magaaleedka |
| 19 | `19_xero_qaxooti.svg` | Xero qaxooti | Refugee camp (tent) | Adkaysiga |

## Usage notes
- **Print maps**: pins reproduce at 10 mm or larger. Below that, the
  pictogram disappears and only the colour remains visible.
- **Digital maps**: pin is anchored at the tip of the point (x=32, y=76
  in the SVG's own coordinate space). For Leaflet `iconAnchor: [32, 80]`.
- **Recolour**: every icon has three colours — fill, stroke, and inner
  pictogram. Edit the SVG to change them.

## Icons to test with target audience before printing at scale
- **Anteeno (12)** — broadcast/signal-arcs is abstract; some users may
  not connect it with "telecom".
- **Xoolo / Geel (14)** — the camel silhouette is recognisable but
  pastoralists are particular about camel proportions. Get a local
  designer to refine.
- **Qorshe magaaleed (18)** — "master plan" is hard to icon because it
  isn't a building. Consider whether it belongs on a public map at all.

## License
These icons are free to use, modify, and redistribute. Several inner
pictograms are derived from the Tabler Icons set (MIT licensed).
